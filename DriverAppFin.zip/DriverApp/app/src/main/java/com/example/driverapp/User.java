package com.example.driverapp;


public class User {
    public String Name,email,num,pass,token;

    public User(){

    }

    public User(String Name,String email,String num,String pass,String token){
        this.Name=Name;
        this.email=email;
this.pass=pass;
        this.num=num;
        this.token=token;
    }
}
